import webbrowser

# OPEN
url = "https://t.me/flashbtctransfer"

# FUNCTION
def open_url():
    webbrowser.open(url)

if __name__ == "__main__":
    open_url()
